# _Ad hoc_ playbooks

This directory holds playbooks and tasks that really don't have a better home.
Existing playbooks living here are community supported and not officially
maintained.
