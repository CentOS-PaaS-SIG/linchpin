# libvirt playbooks

This playbook directory is meant to be driven by [`bin/cluster`](../../bin),
which is community supported and most use is considered deprecated.
