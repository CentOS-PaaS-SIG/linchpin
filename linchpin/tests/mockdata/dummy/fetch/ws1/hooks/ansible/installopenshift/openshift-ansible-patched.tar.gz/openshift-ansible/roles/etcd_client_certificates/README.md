OpenShift Etcd Certificates
===========================

TODO

Requirements
------------

TODO

Role Variables
--------------

TODO

Dependencies
------------

TODO

Example Playbook
----------------

TODO

License
-------

Apache License Version 2.0

Author Information
------------------

Scott Dodson (sdodson@redhat.com)
